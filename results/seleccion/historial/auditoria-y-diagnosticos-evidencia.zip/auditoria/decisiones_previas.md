# Decisiones fijadas antes de medir

Punto de restauración fase23-20261113-152329-a7172f93; copia completa verificada y parches staged/unstaged fuera del repositorio. No se modifica el índice ni se resuelve el merge pendiente.

El objetivo se reconstruye por bloque desde consumo_dia y se anula la última etiqueta del 70% de entrenamiento. TimeSeriesSplit usa gap=1: la etiqueta del último predictor de entrenamiento se obtiene en el bloque de separación, anterior al primer predictor evaluado. Cada prefijo usado para búsqueda interna anula su última etiqueta. Se conservan las filas sin etiqueta para construir memoria y se excluyen después. No se imputa ni escala y. Fechas rotuladas no son fechas físicas certificadas.

La consigna oficial obliga a excluir días con menos de 24 lecturas. Se invalida en la copia experimental, sin alterar los originales ni la implementación ajena. Esta excepción al ADR 0005 se entrega a integración. No se descartan bloques con más de 25 automáticamente: se conserva reconstrucción y desempate documentados.

Limpieza e ingeniería se reaprenden por pliegue. Se reutiliza su resultado únicamente entre configuraciones que comparten exactamente índices, reglas y datos. Las preparaciones univariantes se reutilizan por pliegue, escalador y transformación. No se comparte estado aprendido entre pliegues. Se parte de todas las candidatas numéricas que pasan limpieza, excluyendo controles y constantes; se registran exclusiones por nombre. Las 45 interacciones siguen la ingeniería del ADR 0014, reaprendida.

Pares válidos para correlaciones: al menos 20 observaciones y 60% de cobertura del entrenamiento utilizable, coherente con la tolerancia histórica de 40% de faltantes. Son salvaguardas de calidad declaradas, no umbrales optimizados ni verdades estadísticas. Se conservan rankings completos y cobertura.

Mediana inicial resistente a extremos. Se agregan indicadores de ausencia aprendidos en entrenamiento para distinguir valores observados de rellenos; una razón indefinida en planta parada no se interpreta como un dato real normal. No puede identificarse la causa de toda ausencia. Se informa cantidad de variables originales seleccionadas y dimensión efectiva del estimador, incluidos indicadores. Las variables originales, sin escalar ni transformar, son el contrato del dataset final.

Se comparan StandardScaler y RobustScaler, sin transformación y con Yeo-Johnson. Esta última se aplica a columnas con más de dos valores distintos; antes se divide por una desviación positiva de entrenamiento para estabilidad numérica, sin centrar. Se guardan factor y lambda. Indicadores binarios no se transforman. La limpieza de mediciones imposibles precede a todo escalado. Los extremos legítimos se conservan; el IQR es diagnóstico.

Ridge alpha=100 y solver SVD es el comparador común, no un modelo final. Filtros sin escalado para calcular sus puntajes; Ridge sí usa preparación ajustada. Información mutua usa vecinos=3, semilla=42, mediana y máscara de binarias. Lasso usa max_iter=20000, tol=0.0001 y selección de coeficientes no nulos, incluidos indicadores que obligan a conservar su variable. Las advertencias de convergencia se registran.

Búsqueda amplia de tamaños: 1,2,3,5,10,15,20,30,40,60,80,120 y total de candidatas de cada pliegue; se adapta al ranking disponible. Se refina en torno a la mejor configuración. Alpha inicial 0.1 a 10000 por décadas, refinado logarítmicamente. No se promete óptimo global. Menor MAE medio; equivalencia práctica 1%; menor cantidad efectiva; estabilidad/desvío para empates. El 1% es criterio de ingeniería solicitado, no significación estadística.

Métodos principales: cuatro pliegues externos y tres internos. El MAE externo evalúa el procedimiento de búsqueda, no una lista global preajustada. Seleccionar ganador entre métodos mediante ese MAE introduce optimismo de selección; no se presenta como rendimiento final independiente. Test y validation reservados quedan fuera.

Modificación solicitada para Forward: diez candidatas Spearman por entrenamiento de cada pliegue, de una a cinco directas, Ridge, dos pliegues internos, tres externos y 1800 segundos totales. Para evitar un prefiltro global, se buscan posiciones del ranking local: cada candidato es una regla de selección, cuya identidad puede variar por pliegue. El ajuste definitivo materializa nombres con todo entrenamiento. Se preserva jerarquía. Forward es complementario: no participa del ganador principal por usar otro protocolo. Checkpoints por configuración y trayectoria permiten reanudar. Solo se aceptan rondas completas.

Backward está excluido por costo y alcance: no se ejecuta ni se configura; su código histórico queda intacto. Las pruebas parametrizadas que lo invocan se excluyen con -k not backward. También se omite la prueba real del punto de entrada ajeno que transforma validation/test; se verifica la ruta experimental autorizada.

Primer intento de carga falló por checksum del CSV inicial: CRLF en 1213 líneas. Normalizar exclusivamente esos saltos devuelve exactamente SHA-256 registrado. Se agregó .gitattributes para impedir repetición en git clone. Los tres Excel siempre coincidieron. Error y corrección se preservan.
