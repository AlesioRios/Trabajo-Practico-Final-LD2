"""Activa la nueva etapa solo cuando los cuatro métodos previos estén guardados."""
from pathlib import Path
import json,shutil,re
root=Path.cwd();audit=root/'results/seleccion/auditoria'
assert (audit/'detencion_forward_provisional.json').exists(), 'Esperar detención segura tras Lasso.'
run=root/'results/seleccion/ejecucion-20261113T184058Z-969d4545'
sels=json.loads((run/'selecciones_por_metodo.json').read_text(encoding='utf-8'))
assert {'spearman','pearson','mutua','lasso'}<=sels.keys()
# La versión previa exacta ya está archivada en codigo/ y codigo_revision/.
p=root/'src/experimentos_seleccion.py';s=p.read_text(encoding='utf-8')
# Corregir únicamente textos que atravesaron lecturas Windows con codificación implícita.
for _ in range(4):
    try: candidato=s.encode('cp1252').decode('utf-8')
    except (UnicodeError,LookupError): break
    if candidato==s:break
    s=candidato
s=s.replace("METODOS = ('spearman', 'pearson', 'mutua', 'lasso', 'forward')", "METODOS = ('spearman', 'pearson', 'mutua', 'lasso')")
s=re.sub(r"    forward_prefiltro=.*?forward_segundos=1800,\n",'',s,flags=re.S)
start=s.index("    if metodo=='forward':\n",s.index('def buscar('));end=s.index('    cantidades=sorted(',start)
s=s[:start]+"    if metodo not in METODOS: raise ValueError('Usar seleccion_union_forward.py para los procedimientos combinados.')\n"+s[end:]
start=s.index("                    if m=='forward':\n",s.index('def ejecutar('));end=s.index('                    for o,(inner,outer) in usados.items():',start)
s=s[:start]+s[end:]
s=s.replace("METODOS[METODOS.index(m)+1] if m!='forward' else 'documentacion'", "METODOS[METODOS.index(m)+1] if METODOS.index(m)+1<len(METODOS) else 'union'")
# Contador exacto de configuraciones nuevas tras descartar duplicados de la cuadrícula.
s=s.replace("    previstas+=len(refinados)\n    vistos={clave(r['configuracion']) for r in registros}", "    vistos={clave(r['configuracion']) for r in registros}\n    previstas=len(registros)+sum(clave(dict(cfg,**({'alpha':float(v)} if metodo=='lasso' else {'k':int(v)}))) not in vistos for v in refinados)")
s=s.replace("    actual.update(estado)", "    actual.update(estado)\n    if estado.get('estado') in ('iniciado','ejecutando','completo'): actual.pop('error',None)")
p.write_text(s,encoding='utf-8',newline='\n');compile(s,str(p),'exec')
shutil.copyfile(audit/'seleccion_union_forward_borrador.py',root/'src/seleccion_union_forward.py')
# Las pruebas pasan de borrador a la ubicación establecida por el proyecto.
p=audit/'test_union_borrador.py';t=p.read_text(encoding='utf-8-sig')
a=t.index('ROOT=');b=t.index('from test_preprocessing_pipeline',a)
t=t[:a]+"ROOT=Path(__file__).resolve().parents[1]\nsys.path.insert(0,str(ROOT/'src'))\nimport seleccion_union_forward as u\n"+t[b:]
(root/'tests/test_union_forward.py').write_text(t,encoding='utf-8',newline='\n')
p=root/'tests/test_experimentos_seleccion.py';t=p.read_text(encoding='utf-8')
t=t.replace("    assert e.POLITICA['forward_prefiltro']==10\n    assert e.POLITICA['forward_externos']==3\n    assert e.POLITICA['forward_internos']==2", "    import seleccion_union_forward as u\n    assert u.POLITICA_UNION['paciencia']==3\n    assert u.POLITICA_UNION['externos']==4\n    assert u.POLITICA_UNION['presupuesto_forward_segundos']==1800")
p.write_text(t,encoding='utf-8',newline='\n')
# Conserva el estado de error histórico; publica por separado el hito recuperado.
(run/'estado_individuales.json').write_text(json.dumps(dict(estado='cuatro_metodos_completos',forward_provisional_ejecutado=False,detencion='por cambio explicito de alcance',siguiente='union y Forward bajo protocolo comun'),indent=2),encoding='utf-8')
print('Código activado para cuatro métodos individuales y continuación unión/Forward.')
