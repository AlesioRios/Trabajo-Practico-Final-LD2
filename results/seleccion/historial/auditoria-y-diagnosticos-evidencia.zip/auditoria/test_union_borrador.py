import importlib.util
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'tests'))
spec=importlib.util.spec_from_file_location('union_borrador',Path(__file__).with_name('seleccion_union_forward_borrador.py'))
u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)
from test_preprocessing_pipeline import tabla_sintetica


def test_union_procedencia_y_jerarquia(monkeypatch):
    p=dict(X=pd.DataFrame({'a':[1,2],'b':[3,4],'a x b':[3,8]}),mapa={'a x b':['a','b']})
    monkeypatch.setattr(u.e,'ranking',lambda *args:{'puntajes':{'a':.6,'b':.3,'a x b':.9}})
    r=u.construir_union(p,{'spearman':{'seleccionadas':['a x b']},'lasso':{'seleccionadas':['a']}})
    assert set(r['seleccionadas'])=={'a','b','a x b'}
    assert r['procedencia']['a']==['lasso']
    assert r['procedencia']['b']==[]
    s=u.seleccionar_union(p,dict(metodo='forward',posiciones=[r['orden'].index('a x b')],cap=None))
    assert len(s['directas'])==1
    assert set(s['seleccionadas'])=={'a','b','a x b'}


def test_forward_puede_superar_cinco_y_para_por_paciencia(tmp_path,monkeypatch):
    columnas=[f'x{i}' for i in range(10)]
    p=dict(X=pd.DataFrame({c:[1.,2.] for c in columnas}),mapa={},union={'orden':columnas,'cantidad':10,'procedencia':{c:['spearman'] for c in columnas}})
    errores=[100.,90.,80.,70.,60.,50.,49.9,49.8,49.7,49.6]
    propuestas=[]
    def evaluar(ps,cfg,carpeta,contexto):
        n=len(cfg['posiciones']);propuestas.append(n)
        return dict(id=u.e.clave(cfg),estado='completo',mae=errores[n-1],std=0.,cantidad=n,configuracion=cfg)
    monkeypatch.setattr(u.e,'evaluar_config',evaluar)
    monkeypatch.setattr(u.e,'progreso',lambda *args,**kwargs:None)
    r=u.buscar_forward([p,p],dict(escalador='standard',transformacion='ninguna'),None,tmp_path,'caso',u.time.perf_counter()+30)
    assert len(r['configuracion']['posiciones'])==6
    checkpoint=u.leer(tmp_path/'forward/caso.json')
    assert checkpoint['estado']=='tres_incorporaciones_sin_mejora_relevante'
    assert len(checkpoint['trayectoria'])==9
    antes=len(propuestas)
    assert u.buscar_forward([p,p],dict(escalador='standard',transformacion='ninguna'),None,tmp_path,'caso',0)==r
    assert len(propuestas)==antes


def test_union_local_usa_sus_propias_reglas_y_no_futuro(tmp_path,monkeypatch):
    t=tabla_sintetica(100).assign(valido=True)
    p=u.e.preparar_pliegue(t,np.arange(60),np.arange(61,80))
    def buscar(ps,m,carpeta,contexto):
        cfg=dict(metodo=m,k=1,escalador='standard',transformacion='ninguna',alpha=100.)
        return dict(id='sintetico_'+m,configuracion=cfg)
    monkeypatch.setattr(u.e,'buscar',buscar)
    monkeypatch.setattr(u.e,'progreso',lambda *args,**kwargs:None)
    u.union_local(t,p,tmp_path,'local',{})
    assert 59 not in p['X'].index
    assert set(p['union']['seleccionadas'])<=set(p['X'].columns)
    assert max(p['X'].index)<min(p['V'].index)-1
    assert all(set(p['mapa'].get(c,[]))<=set(p['union']['seleccionadas']) for c in p['union']['seleccionadas'])


def test_registros_compartidos_conservan_datos_y_no_duplican(tmp_path,monkeypatch):
    monkeypatch.setattr(u,'CARPETA_ACTIVA',tmp_path)
    x={'pliegues':[{'seleccion':{'ranking':{'a':.9,'b':.3}},'mae':5.}]}
    u.guardar_normalizado(tmp_path/'uno.json',x)
    u.guardar_normalizado(tmp_path/'dos.json',x)
    r=u.leer(tmp_path/'uno.json')
    ref=r['pliegues'][0]['seleccion']['ranking_ref']
    assert u.leer(tmp_path/ref)=={'a':.9,'b':.3}
    assert len(list((tmp_path/'tablas_compartidas').glob('*.json')))==1
    assert x['pliegues'][0]['seleccion']['ranking']=={'a':.9,'b':.3}
