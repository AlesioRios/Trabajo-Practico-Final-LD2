"""Continúa selección: unión y Forward con evaluación externa común y prefiltros causales."""
import argparse
import json
import shutil
import sys
import time
import traceback
import uuid
from datetime import datetime,timezone,timedelta
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit
from threadpoolctl import threadpool_limits
import experimentos_seleccion as e

INDIVIDUALES=('spearman','pearson','mutua','lasso')
SELECCION_ORIGINAL=e.seleccionar
GUARDAR_ORIGINAL=e.guardar
CARPETA_ACTIVA=None
POLITICA_UNION=dict(externos=4,internos=3,gap=1,paciencia=3,mejora_relevante=.01,
    presupuesto_forward_segundos=1800,reducciones=[20,25,30],
    criterio='MAE, margen 1%, menor cantidad efectiva, estabilidad',
    candidatos='union sin duplicados de mejores selectores locales; jerarquia explicita')


def leer(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def guardar_normalizado(ruta,obj):
    """Tablas inmutables compartidas por SHA-256; conserva todo valor sin duplicarlo."""
    if Path(ruta).name in {'configuraciones.json','datos.json','progreso.json','checksums_artefactos.json','estado.json'}:
        return GUARDAR_ORIGINAL(ruta,obj)
    claves={'ranking','preparacion','preparacion_selector','union_procedencia','orden_prefiltro'}
    def recorrer(x):
        if isinstance(x,list):return [recorrer(v) for v in x]
        if not isinstance(x,dict):return x
        nuevo={}
        for k,v in x.items():
            if k in claves and isinstance(v,(dict,list)):
                contenido=json.dumps(e.normalizar(v),sort_keys=True,ensure_ascii=False,allow_nan=False)
                sha=e.hashlib.sha256(contenido.encode('utf-8')).hexdigest()
                archivo=CARPETA_ACTIVA/'tablas_compartidas'/f'{sha}.json'
                if not archivo.exists():GUARDAR_ORIGINAL(archivo,v)
                nuevo[k+'_ref']=archivo.relative_to(CARPETA_ACTIVA).as_posix()
            else:nuevo[k]=recorrer(v)
        return nuevo
    GUARDAR_ORIGINAL(ruta,recorrer(obj))


def construir_union(p,selecciones):
    """Conserva procedencia, padres y orden local; no lee el tramo evaluado."""
    conjuntos={m:set(r['seleccionadas']) for m,r in selecciones.items()}
    union=e.cerrar_jerarquia(sorted(set().union(*conjuntos.values())),p['mapa'],p['X'].columns)
    scores=e.ranking(p,'spearman')['puntajes']
    apoyo={c:[m for m,cs in conjuntos.items() if c in cs] for c in union}
    orden=sorted(union,key=lambda c:(-len(apoyo[c]),-abs(scores.get(c) or 0.),c))
    p['union']=dict(seleccionadas=union,orden=orden,procedencia=apoyo,
        componentes=p['mapa'],cantidad=len(union),
        puntajes_orden={c:scores.get(c) for c in union})
    return p['union']


def seleccionar_union(p,cfg):
    """Despacho adicional; los cuatro selectores individuales permanecen sin cambios."""
    if cfg['metodo'] not in ('union','forward'):return SELECCION_ORIGINAL(p,cfg)
    orden=p['union']['orden']
    cap=cfg.get('cap')
    disponibles=orden if cap is None else orden[:cap]
    if cfg['metodo']=='union':directas=disponibles
    else:
        if any(pos>=len(disponibles) for pos in cfg['posiciones']):
            raise ValueError('Posición ausente en la unión causal de este pliegue.')
        directas=[disponibles[pos] for pos in cfg['posiciones']]
    elegidas=e.cerrar_jerarquia(directas,p['mapa'],p['X'].columns)
    return dict(directas=directas,seleccionadas=elegidas,
        por_jerarquia=[c for c in elegidas if c not in directas],
        union_cantidad=p['union']['cantidad'],union_procedencia=p['union']['procedencia'],
        componentes=p['mapa'],orden_prefiltro=disponibles)


def recuperar_pliegue(tabla,archivo):
    """Reaplica reglas auditadas del mismo prefijo sin recalcular limpieza e ingeniería."""
    a=leer(archivo);fin=a['fin_train'];inicio=a['inicio_eval'];ids=a['eval_indices']
    historia=tabla.iloc[:max(ids)+1] if ids else tabla.iloc[:fin+1]
    creada=e.aplicar_ingenieria(e.limpiar(historia,a['limpieza']),a['ingenieria'])
    tr=creada.loc[a['train_indices']];va=creada.loc[ids]
    X=tr.drop(columns=e.COLUMNAS_DE_CONTROL,errors='ignore').astype(float)
    return dict(X=X,y=tr.objetivo,V=va.reindex(columns=X.columns).astype(float),z=va.objetivo,
        mapa=e.construir_mapa_interacciones(a['ingenieria']),candidatas=a['candidatas'],
        audit=a,rankings={},preparaciones={})


def union_local(tabla,p,carpeta,nombre,memoria):
    """Busca cada selector en pliegues anteriores al entrenamiento del pliegue actual."""
    limite=p['audit']['fin_train']+1
    if limite in memoria:
        selecciones=memoria[limite]
    else:
        ruta=carpeta/'uniones'/f'prefijo_{limite}_selectores.json'
        if ruta.exists():selecciones=leer(ruta)
        else:
            bruto=tabla.iloc[:limite].copy();bruto.iloc[-1,bruto.columns.get_loc('objetivo')]=np.nan
            # Mantener >=30 bloques iniciales en prefijos muy pequeños; hasta tres pliegues.
            tam=min(len(bruto)//4,max(1,(len(bruto)-31)//3))
            particion=TimeSeriesSplit(3,gap=1,test_size=tam)
            internos=[e.preparar_pliegue(bruto,i,j,carpeta,f'prefijo{limite}_interno{k}')
                for k,(i,j) in enumerate(particion.split(bruto))]
            ajuste=e.preparar_pliegue(bruto,np.arange(len(bruto)),np.array([],dtype=int),carpeta,f'prefijo{limite}_ajuste')
            selecciones={}
            for m in INDIVIDUALES:
                e.progreso(carpeta,'union',estado='aprendiendo_prefiltro_causal',prefijo=limite,metodo_local=m,contexto=nombre)
                mejor=e.buscar(internos,m,carpeta,f'prefijo{limite}_{m}')
                selecciones[m]=dict(SELECCION_ORIGINAL(ajuste,mejor['configuracion']),
                    configuracion=mejor['configuracion'],id_busqueda=mejor['id'])
            e.guardar(ruta,selecciones)
        memoria[limite]=selecciones
    # Aplicar exactamente la ingeniería del ajuste local sin su última etiqueta.
    # Las bases supervisadas pueden diferir de las del pliegue principal.
    audit=leer(carpeta/'preparacion'/f'prefijo{limite}_ajuste.json')
    audit['eval_indices']=p['audit']['eval_indices']
    audit['inicio_eval']=p['audit']['inicio_eval']
    ruta_audit=carpeta/'preparacion'/f'{nombre}_union_causal.json'
    e.guardar(ruta_audit,audit)
    copia=tabla.copy();copia.iloc[limite-1,copia.columns.get_loc('objetivo')]=np.nan
    nuevo=recuperar_pliegue(copia,ruta_audit)
    p.clear();p.update(nuevo)
    union=construir_union(p,selecciones)
    e.guardar(carpeta/'uniones'/f'{nombre}.json',union)
    return union


def buscar_forward(pliegues,prep,cap,carpeta,contexto,limite):
    """Sin máximo arbitrario de variables; paciencia y presupuesto, rondas completas."""
    inicio=time.perf_counter();pos=[];tray=[];sin_mejora=0;best=float('inf');evaluaciones=0
    n=min(len(p['union']['orden']) if cap is None else min(cap,len(p['union']['orden'])) for p in pliegues)
    ruta=carpeta/'forward'/f'{contexto}.json';motivo='agotadas_candidatas'
    if ruta.exists():
        anterior=leer(ruta)
        if anterior['estado'] in ('agotadas_candidatas','tres_incorporaciones_sin_mejora_relevante'):
            return anterior['mejor']
        tray=anterior.get('trayectoria',[])
        if tray:
            pos=tray[-1]['configuracion']['posiciones'];best=min(r['mae'] for r in tray)
            sin_mejora=anterior.get('sin_mejora',0);evaluaciones=anterior.get('ajustes',0)
    for paso in range(len(pos),n):
        ronda=[]
        for c in range(n):
            if c in pos:continue
            if time.perf_counter()>=limite:
                motivo='presupuesto';break
            cfg=dict(metodo='forward',posiciones=pos+[c],cap=cap,**prep)
            # No contar como incorporación un padre ya presente por cierre en todos los pliegues.
            if pos and all(set(seleccionar_union(p,cfg)['seleccionadas'])==set(seleccionar_union(p,dict(cfg,posiciones=pos))['seleccionadas']) for p in pliegues):continue
            r=e.evaluar_config(pliegues,cfg,carpeta,contexto);evaluaciones+=len(pliegues)
            if r['estado']=='completo':ronda.append(r)
            e.progreso(carpeta,'forward',estado='ejecutando',contexto=contexto,ronda=paso+1,
                candidatas=n,configuraciones_completadas=evaluaciones//len(pliegues),
                configuraciones_maximas=n*(n+1)//2,segundos=time.perf_counter()-inicio,
                mejor_mae=None if not np.isfinite(best) else best)
        if motivo=='presupuesto' or not ronda:break
        elegido=min(ronda,key=lambda r:(r['mae'],r['cantidad'],r['id']))
        mejora=best-elegido['mae'];relevante=not np.isfinite(best) or mejora>=.01*best
        sin_mejora=0 if relevante else sin_mejora+1
        best=min(best,elegido['mae']);pos=elegido['configuracion']['posiciones']
        tray.append(elegido)
        e.guardar(ruta,dict(estado='ejecutando',trayectoria=tray,mejor=e.elegir(tray),
            sin_mejora=sin_mejora,ajustes=evaluaciones,candidatas=n,segundos=time.perf_counter()-inicio))
        print(f'FORWARD {contexto}: {len(pos)} directas, MAE interno={elegido["mae"]:.3f}, paciencia={sin_mejora}/3',flush=True)
        if sin_mejora>=3:motivo='tres_incorporaciones_sin_mejora_relevante';break
    e.guardar(ruta,dict(estado=motivo,trayectoria=tray,mejor=e.elegir(tray) if tray else None,
        sin_mejora=sin_mejora,ajustes=evaluaciones,candidatas=n,segundos=time.perf_counter()-inicio))
    if not tray:raise RuntimeError('Sin ronda Forward completa; resultados parciales preservados.')
    return e.elegir(tray)


def _continuar_impl(origen,carpeta=None):
    global CARPETA_ACTIVA
    origen=Path(origen).resolve();selecciones=leer(origen/'selecciones_por_metodo.json')
    if not set(INDIVIDUALES)<=selecciones.keys():raise ValueError('Completar primero cuatro métodos individuales.')
    carpeta=Path(carpeta).resolve() if carpeta else e.RAIZ/'results/seleccion'/('ejecucion-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-union-'+uuid.uuid4().hex[:8])
    carpeta.mkdir(parents=True,exist_ok=True);print('CONTINUACION',carpeta,flush=True)
    CARPETA_ACTIVA=carpeta
    e.guardar=guardar_normalizado
    e.seleccionar=seleccionar_union
    firma=e.firma_codigo()
    if not (carpeta/'configuraciones.json').exists():
        cfg=leer(origen/'configuraciones.json');cfg.update(codigo=firma,politica=e.POLITICA,politica_union=POLITICA_UNION,
            procedencia_principales=origen.relative_to(e.RAIZ).as_posix(),
            codigo_sin_commit_sha256=e.hashlib.sha256(json.dumps(firma,sort_keys=True).encode()).hexdigest())
        e.guardar(carpeta/'configuraciones.json',cfg)
        for nombre in firma:
            destino=carpeta/'codigo'/nombre;destino.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(e.RAIZ/nombre,destino)
        for sub in ['experimentos','preparacion','intentos_previos','codigo','codigo_revision']:
            if (origen/sub).exists():
                destino=carpeta/sub if sub in ['experimentos','preparacion','intentos_previos'] else carpeta/'origen_principales'/sub
                shutil.copytree(origen/sub,destino,dirs_exist_ok=True)
        e.guardar(carpeta/'origen_principales/configuraciones.json',leer(origen/'configuraciones.json'))
        if (origen/'revision_codigo.json').exists():e.guardar(carpeta/'origen_principales/revision_codigo.json',leer(origen/'revision_codigo.json'))
        e.guardar(carpeta/'experimentos_reutilizados.json',{p.name:e.huella(p) for p in (origen/'experimentos').glob('*.json')})
    elif leer(carpeta/'configuraciones.json')['codigo']!=firma:raise ValueError('Código cambiado: requiere revisión antes de reanudar.')
    e.evento(carpeta,'inicio_continuacion',origen=origen.name,politica=POLITICA_UNION)
    try:
        with threadpool_limits(limits=1):
            train,datos=e.cargar_entrenamiento();e.guardar(carpeta/'datos.json',datos)
            inicio_union_general=time.perf_counter()
            registros=[leer(p) for p in (origen/'experimentos').glob('*.json')]
            externos={m:[] for m in INDIVIDUALES};contextos={};memoria={};cfg_verificacion={}
            for o,(i,j) in enumerate(TimeSeriesSplit(4,gap=1).split(train)):
                p=recuperar_pliegue(train,origen/'preparacion'/f'externo{o}.json')
                sels={}
                for m in INDIVIDUALES:
                    r=next(r for r in registros if r['contexto']==f'{m}_evaluacion_externa{o}' and r['estado']=='completo')
                    externos[m].append(r['pliegues'][0]);sels[m]=r['pliegues'][0]['seleccion']
                    if o==0:cfg_verificacion[m]=r['configuracion']
                construir_union(p,sels);e.guardar(carpeta/'uniones'/f'externo{o}.json',p['union'])
                prefijo=train.iloc[i].copy();prefijo.iloc[-1,prefijo.columns.get_loc('objetivo')]=np.nan
                internos=[]
                for k,(a,b) in enumerate(TimeSeriesSplit(3,gap=1).split(prefijo)):
                    q=recuperar_pliegue(prefijo,origen/'preparacion'/f'externo{o}_interno{k}.json')
                    union_local(prefijo,q,carpeta,f'externo{o}_interno{k}',memoria);internos.append(q)
                contextos[f'externo{o}']=(internos,p)
            final_p=recuperar_pliegue(train,origen/'preparacion/final.json')
            construir_union(final_p,{m:selecciones[m]['seleccion'] for m in INDIVIDUALES})
            e.guardar(carpeta/'uniones/ajuste_final.json',final_p['union'])
            internos=[]
            for k,(i,j) in enumerate(TimeSeriesSplit(3,gap=1).split(train)):
                q=recuperar_pliegue(train,origen/'preparacion'/f'final_interno{k}.json')
                union_local(train,q,carpeta,f'final_interno{k}',memoria);internos.append(q)
            contextos['ajuste_final']=(internos,final_p)
            resumen=pd.read_csv(origen/'resumen_resultados.csv').query("metodo != 'forward'").to_dict('records')
            finales={m:selecciones[m] for m in INDIVIDUALES};union_evals=[];forward_evals=[];preps={};caps={}
            inicio_union=time.perf_counter()
            for contexto,(internos,p) in contextos.items():
                opciones=[]
                for escala in e.POLITICA['escaladores']:
                    for transformacion in e.POLITICA['transformaciones']:
                        cfg=dict(metodo='union',cap=None,escalador=escala,transformacion=transformacion)
                        opciones.append(e.evaluar_config(internos,cfg,carpeta,'union_'+contexto))
                mejor=e.elegir(opciones);preps[contexto]={k:mejor['configuracion'][k] for k in ['escalador','transformacion']}
                reducciones=[mejor]
                if p['union']['cantidad']>30:
                    for cap in [20,25,30]:
                        reducciones.append(e.evaluar_config(internos,dict(metodo='union',cap=cap,**preps[contexto]),carpeta,'reduccion_'+contexto))
                elegida=e.elegir(reducciones);caps[contexto]=elegida['configuracion']['cap']
                e.guardar(carpeta/'uniones'/f'reduccion_{contexto}.json',dict(comparadas=reducciones,elegida=elegida['id'],cap=caps[contexto]))
                if contexto!='ajuste_final':
                    r=e.evaluar_config([p],mejor['configuracion'],carpeta,'union_evaluacion_'+contexto)
                    if r['estado']!='completo':raise RuntimeError(r.get('error'))
                    union_evals.append(r['pliegues'][0])
                    if contexto=='externo0':cfg_verificacion['union']=mejor['configuracion']
                else:
                    sel=seleccionar_union(p,mejor['configuracion'])
                    finales['union']=dict(configuracion=mejor['configuracion'],seleccion=sel,seleccionadas=sel['seleccionadas'],id_busqueda=mejor['id'])
            def resumir(m,fs,segundos):
                frec,pares=e.resumir_estabilidad(fs);frec.to_csv(carpeta/f'estabilidad_{m}.csv',index=False)
                return dict(metodo=m,mae=float(np.mean([f['mae'] for f in fs])),std=float(np.std([f['mae'] for f in fs])),
                    cantidad=len(finales[m]['seleccionadas']),cantidad_cv=float(np.mean([f['cantidad'] for f in fs])),
                    jaccard=float(pares.Jaccard.mean()),segundos=segundos,configuracion=json.dumps(finales[m]['configuracion']),
                    estado='completo',protocolo='principal_4x3')
            externos['union']=union_evals;resumen.append(resumir('union',union_evals,time.perf_counter()-inicio_union_general))
            e.guardar(carpeta/'selecciones_por_metodo.json',finales);pd.DataFrame(resumen).to_csv(carpeta/'resumen_resultados.csv',index=False)
            e.progreso(carpeta,'union',estado='completo',resultado=resumen[-1],candidatas_finales=final_p['union']['cantidad'])
            # Presupuesto acumulado persistente; reanudar no reinicia los 30 minutos.
            presupuesto=carpeta/'forward/presupuesto.json'
            previo=leer(presupuesto) if presupuesto.exists() else {}
            consumido=previo.get('segundos_consumidos',0.)
            vencimiento=datetime.fromisoformat(previo['vencimiento_utc']) if 'vencimiento_utc' in previo else datetime.now(timezone.utc)+timedelta(seconds=max(0.,1800-consumido))
            inicio=time.perf_counter();limite=inicio+max(0.,(vencimiento-datetime.now(timezone.utc)).total_seconds())
            e.guardar(presupuesto,dict(segundos_consumidos=consumido,maximo=1800,vencimiento_utc=vencimiento.isoformat()))
            try:
                for numero,(contexto,(internos,p)) in enumerate(contextos.items()):
                    cuota=time.perf_counter()+max(0.,limite-time.perf_counter())/(len(contextos)-numero)
                    mejor=buscar_forward(internos,preps[contexto],caps[contexto],carpeta,'forward_'+contexto,min(cuota,limite))
                    if contexto!='ajuste_final':
                        r=e.evaluar_config([p],mejor['configuracion'],carpeta,'forward_evaluacion_'+contexto)
                        if r['estado']!='completo':raise RuntimeError(r.get('error'))
                        forward_evals.append(r['pliegues'][0])
                        if contexto=='externo0':cfg_verificacion['forward']=mejor['configuracion']
                    else:
                        sel=seleccionar_union(p,mejor['configuracion'])
                        finales['forward']=dict(configuracion=mejor['configuracion'],seleccion=sel,seleccionadas=sel['seleccionadas'],id_busqueda=mejor['id'])
                    e.guardar(presupuesto,dict(segundos_consumidos=consumido+time.perf_counter()-inicio,maximo=1800,vencimiento_utc=vencimiento.isoformat()))
                externos['forward']=forward_evals;resumen.append(resumir('forward',forward_evals,time.perf_counter()-inicio))
            except Exception:
                e.evento(carpeta,'forward_parcial',error=traceback.format_exc());e.progreso(carpeta,'forward',estado='parcial',error=traceback.format_exc())
            finally:e.guardar(presupuesto,dict(segundos_consumidos=consumido+time.perf_counter()-inicio,maximo=1800,vencimiento_utc=vencimiento.isoformat()))
            for fs in externos.values():
                assert len(fs)==4, 'Comparación requiere cuatro pliegues externos completos.'
                assert [f['indices_evaluados'] for f in fs]==[f['indices_evaluados'] for f in externos['spearman']], 'Filas externas incompatibles.'
            e.progreso(carpeta,'forward',estado='completo' if 'forward' in finales else 'parcial',segundos_etapa=time.perf_counter()-inicio)
            minimo=min(r['mae'] for r in resumen)
            ganador=min([r for r in resumen if r['mae']<=1.01*minimo],key=lambda r:(r['cantidad'],-r['jaccard'],r['std'],r['metodo']))
            contrato=dict(ganador=ganador,**finales[ganador['metodo']],reglas_limpieza=final_p['audit']['limpieza'],
                reglas_variables=final_p['audit']['ingenieria'],semilla=42,datos=datos,codigo=firma,
                politica=e.POLITICA,politica_union=POLITICA_UNION,
                integracion=dict(dataset='data/processed/dataset_final.csv',linaje='data/processed/data_lineage.json',
                    estado='pendiente modulo 2.4; no sobrescrito',sin_escalar=True,sin_transformacion=True,
                    invalidar_menos_24=True,ultima_etiqueta_train_excluida=True))
            e.guardar(carpeta/'variables_seleccionadas.json',contrato);e.guardar(carpeta/'selecciones_por_metodo.json',finales)
            e.guardar(carpeta/'resultados_externos.json',externos);pd.DataFrame(resumen).to_csv(carpeta/'resumen_resultados.csv',index=False)
            pruebas=[]
            p=contextos['externo0'][1]
            for m,v in finales.items():
                cfg=cfg_verificacion[m];a=e.medir(p,cfg);b=e.medir(p,cfg)
                pruebas.append(dict(metodo=m,mae_1=a['mae'],mae_2=b['mae'],mismas_variables=a['seleccionadas']==b['seleccionadas'],predicciones_identicas=a['predicciones']==b['predicciones']))
            e.guardar(carpeta/'determinismo.json',pruebas)
            assert all(p['mismas_variables'] and p['predicciones_identicas'] for p in pruebas)
            final_p['X'][contrato['seleccionadas']].corr(method='spearman').to_csv(carpeta/'correlaciones_finales.csv')
            e.exportar(carpeta);e.guardar(carpeta/'estado.json',dict(estado='completo',ganador=ganador,test_utilizado=False,fecha=datetime.now(timezone.utc).isoformat()))
            e.guardar(carpeta/'checksums_artefactos.json',{p.relative_to(carpeta).as_posix():e.huella(p) for p in carpeta.rglob('*') if p.is_file() and p.name!='checksums_artefactos.json'})
            print('GANADOR COMUN',ganador,flush=True);return carpeta
    except BaseException:
        e.evento(carpeta,'error_continuacion',error=traceback.format_exc());e.exportar(carpeta);raise


def continuar(origen,carpeta=None):
    """Restaura los auxiliares originales al salir; permite otros usos en el mismo kernel."""
    global CARPETA_ACTIVA
    try:
        return _continuar_impl(origen,carpeta)
    finally:
        e.guardar=GUARDAR_ORIGINAL
        e.seleccionar=SELECCION_ORIGINAL
        CARPETA_ACTIVA=None


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('origen',type=Path);parser.add_argument('--reanudar',type=Path)
    args=parser.parse_args();continuar(args.origen,args.reanudar)
