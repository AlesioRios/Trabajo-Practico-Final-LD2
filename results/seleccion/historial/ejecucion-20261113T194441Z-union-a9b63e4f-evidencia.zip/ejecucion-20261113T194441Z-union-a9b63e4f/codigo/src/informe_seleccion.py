"""Lectura verificada de resultados y documentación calculada, sin ajustar modelos."""
import json
from pathlib import Path
import pandas as pd
from auxiliar_functions import huella

RAIZ=Path(__file__).resolve().parents[1]


def cargar_resultados(carpeta=None):
    """Carga una ejecución completa verificando fuentes, código archivado y artefactos."""
    if carpeta is None:
        candidatas=sorted((RAIZ/'results/seleccion').glob('ejecucion-*'),reverse=True)
        carpeta=next((p for p in candidatas if (p/'estado.json').exists() and
            json.loads((p/'estado.json').read_text(encoding='utf-8')).get('estado')=='completo'),None)
        if carpeta is None: raise FileNotFoundError('No hay ejecución completa. Ejecutar python src/experimentos_seleccion.py.')
    carpeta=Path(carpeta)
    hashes=json.loads((carpeta/'checksums_artefactos.json').read_text(encoding='utf-8'))
    malos=[p for p,h in hashes.items() if not (carpeta/p).is_file() or huella(carpeta/p)!=h]
    if malos: raise ValueError(f'Artefactos alterados: {malos}')
    leer=lambda n:json.loads((carpeta/n).read_text(encoding='utf-8'))
    cfg=leer('configuraciones.json')
    for nombre,h in cfg['codigo'].items():
        if huella(carpeta/'codigo'/nombre)!=h: raise ValueError(f'Código archivado distinto: {nombre}')
    for nombre,h in cfg['fuentes'].items():
        if huella(RAIZ/'data'/nombre)!=h: raise ValueError(f'Fuente distinta: {nombre}')
    return dict(carpeta=carpeta,config=cfg,contrato=leer('variables_seleccionadas.json'),
        selecciones=leer('selecciones_por_metodo.json'),externos=leer('resultados_externos.json'),
        determinismo=pd.DataFrame(leer('determinismo.json')),datos=leer('datos.json'),
        resumen=pd.read_csv(carpeta/'resumen_resultados.csv'),
        experimentos=pd.read_csv(carpeta/'experimentos.csv'),
        perfil=pd.read_csv(carpeta/'preparacion/final_perfil.csv'))


def markdown(tabla):
    """Tabla Markdown sin dependencia opcional tabulate."""
    def celda(x):
        if isinstance(x,float): return f'{x:.6f}'
        return str(x).replace('|','\\|').replace('\n',' ')
    return '\n'.join(['| '+' | '.join(map(celda,tabla.columns))+' |',
        '| '+' | '.join(['---']*len(tabla.columns))+' |']+
        ['| '+' | '.join(map(celda,fila))+' |' for fila in tabla.itertuples(index=False,name=None)])


def coincidencias(selecciones):
    nombres=sorted(set().union(*(set(r['seleccionadas']) for r in selecciones.values())))
    return pd.DataFrame([dict(variable=c,**{m:c in r['seleccionadas'] for m,r in selecciones.items()}) for c in nombres])


def checklist(r):
    filas=[
    ('0.1 Python 3.12, conda y uv','requirements.txt; auditoria/entorno.json','Python 3.12.14; 129 versiones coinciden; uv pip check compatible','Verificado localmente','Instalación limpia independiente por verificar'),
    ('0.1 Dependencias congeladas','requirements.txt','129 versiones específicas, sin cambios de dependencias','Verificado','Ninguno local'),
    ('0.2 Repositorio y remoto','Git; README.md','HEAD y rama registrados; remoto existente','Verificado','Publicar únicamente con autorización'),
    ('0.2 README desde git clone','README.md; .gitattributes','Comandos, datos, reconstrucción, ejecución, hashes y pruebas documentados','Documentado; validación local','No se certifica otra máquina'),
    ('0.3 Ramas y Pull Requests','Git; docs/informes/pr_seleccion.md','Rama feature/preprocessing-seleccion conservada; merge previo pendiente','Pendiente de integración','Revisión humana; finalizar merge, commit y PR autorizados'),
    ('1.1 Fuentes originales y SHA-256','data/checksums.json; auditoria','Tres Excel y CSV inicial verificados; CSV corregido solo LF','Verificado','Originales se obtienen del aula virtual'),
    ('1.1 Bloques diarios, solapamiento y cierre','src/auxiliar_functions.py; preprocessing_pipeline.py','Constructor existente reconstruido desde originales, sin modificar originales','Verificado en reconstrucción','Calendario real incierto; más de 25 registros requiere interpretación por bloque'),
    ('2.1 Días inválidos y valores imposibles','src/experimentos_seleccion.py; limpieza.py','Reglas y celdas anuladas por pliegue; menos de 24 lecturas excluidas','Verificado en ruta experimental','Integrar regla estricta en punto de entrada 2.4'),
    ('2.1 Faltantes y extremos','preparacion/*_perfil.csv; experimentos/*.json','Mediana, indicadores, cuartiles, IQR, percentiles; parámetros por pliegue','Verificado','Ausencia no identifica siempre parada o falla de medición'),
    ('2.2 Ingeniería causal','variables_temporales.py; variables_planta.py; variables_interacciones.py','Reglas reaprendidas dentro de cada entrenamiento; pruebas de futuro','Verificado','Etiquetas calendario potencialmente desplazadas'),
    ('2.2 Metas y clima sugeridos','ADR 0009 y 0011','Exclusiones históricas justificadas; no obligatorias','Conservado','No reevaluado en esta etapa'),
    ('2.3 Al menos dos métodos','results/seleccion/'+r['carpeta'].name,'Spearman, Pearson, mutua y Lasso con protocolo común; Forward complementario','Verificado','No incluye Backward'),
    ('2.3 Conjunto justificado y jerarquía','variables_seleccionadas.json; ADR 0015','MAE temporal anidado, equivalencia 1%, padres explícitos','Verificado','Revisión del equipo antes de integración'),
    ('2.4 Separación 70/15/15','datos.json','Cortes por posición; validation y test no intervienen en selección','Verificado','Shapes finales tras selección y descarte dependen del módulo 2.4'),
    ('2.4 Transformación aprendida solo train','src/experimentos_seleccion.py','Mediana, indicadores, lambda, centro y escala por pliegue','Verificado para experimentos','Pipeline definitivo a integrar'),
    ('2.4 Dataset final sin escalar','contrato variables_seleccionadas.json','Lista y reglas exportadas; no se sobrescribe implementación ajena','Pendiente de integración','Generar data/processed/dataset_final.csv y su SHA-256'),
    ('2.4 Linaje de datos','variables_seleccionadas.json; configuraciones.json','Fuentes, hashes, código archivado, reglas, fechas, semilla y particiones','Preparado para integración','Incorporar en data/processed/data_lineage.json, sin esquema paralelo'),
    ('Reproducibilidad: SEMILLA=42','src/auxiliar_functions.py; configuraciones.json','Todos los estimadores aleatorios usan 42; un hilo numérico','Verificado','No garantiza identidad binaria entre hardware distinto'),
    ('Reproducibilidad: dos ejecuciones','determinismo.json','Dos ajustes consecutivos por método: MAE, nombres y predicciones comparados','Verificado parcialmente','No equivale a repetir toda la búsqueda en otra máquina'),
    ('Estructura de entrega','README.md; docs; src; tests; notebooks; results','Artefactos en ubicaciones establecidas','Cumplido para esta etapa','Cierre 2.4 y entregables futuros'),
    ('Notebook ejecutado desde cero','notebooks/seleccion_de_variables.ipynb','Consultar auditoria/notebook_ejecucion.json','Por verificar al generar este informe','La evidencia de ejecución debe existir'),
    ('Fase 3: modelos, baselines y test','consigna.md','Fuera del alcance; no entrenados ni evaluados en test','Fase posterior','Modelado, registro y evaluación final'),
    ('Fase 4: predict.py y modelo versionado','consigna.md','Fuera del alcance','Fase posterior','Pipeline de predicción y contrato de entrada'),
    ('Revisión y contribuciones reales','Git; borrador PR','Sin commits, push, PR ni atribuciones fabricadas','Pendiente autorizado','Revisión por otra persona e historial real')]
    return pd.DataFrame(filas,columns=['Requisito oficial','Archivo o implementación','Evidencia','Estado','Pendiente'])


def generar_informe(carpeta=None):
    """Genera informe exhaustivo y ADR desde registros verificables, nunca cifras manuales."""
    r=cargar_resultados(carpeta);out=RAIZ/'docs/informes';out.mkdir(parents=True,exist_ok=True)
    contrato=r['contrato'];ganador=contrato['ganador'];base=r['carpeta'].relative_to(RAIZ).as_posix()
    resumen=r['resumen'];ex=r['experimentos'];principales=resumen[resumen.metodo!='forward']
    minimo=principales.mae.min();equiv=principales[principales.mae<=minimo*1.01]
    tablas=[]
    def tabla(titulo,df):
        tablas.append(f'### Tabla {len(tablas)+1}. {titulo}\n\n'+markdown(df)+'\n')
        return tablas[-1]
    contenido=f'''# Informe de selección de variables — Fase 2.3

Este informe describe la ejecución `{r['carpeta'].name}`. Los números se calculan desde sus archivos; no provienen de salidas históricas. La recomendación principal es **{ganador['metodo']}**, con **{ganador['cantidad']} variables originales** después del cierre de jerarquía y un MAE externo medio de **{ganador['mae']:.6f} kW**, desviación entre pliegues **{ganador['std']:.6f} kW**. Esto evalúa selección con Ridge de referencia, no un modelo final de Fase 3 ni rendimiento en test.

## A. Qué se hizo y qué significa

Una variable predictora es una medición conocida cuando se emite el pronóstico, por ejemplo el consumo de frío de hoy. La etiqueta es el consumo del bloque siguiente. Si hoy se observaron 100, mañana 120 y pasado mañana 90 kW, las parejas utilizables son (100,120) y (120,90). La última fila no tiene etiqueta. Los bloques conservan el orden y la reconstrucción del proyecto: fechas impresas repetidas no se reinterpretan como fechas físicas comprobadas.

Se preservó el estado previo completo; se verificaron los originales mediante SHA-256; se reconstruyó la tabla diaria y se aisló el 70% más antiguo. Se aplicó limpieza, ingeniería, preparación y selección dentro de cada prefijo temporal. Se exploraron cantidades y regularizaciones, se evaluó el procedimiento en pliegues posteriores y se materializó una lista final usando exclusivamente entrenamiento. Se registraron resultados buenos, malos y fallidos. No se completó el merge ni se hicieron commits, push o Pull Requests.

## B. Cómo funciona cada método

Spearman ordena valores: con X=[1,2,3,4] y y=[1,4,9,16] conserva una relación creciente perfecta aunque no sea lineal. Pearson mide relación lineal entre magnitudes y responde con fuerza a valores extremos; una medición de un millón puede alterar la pendiente y la correlación. Ambos usan pares válidos, no imputación para calcular el coeficiente. Se exige cobertura de 60% y al menos 20 observaciones; son controles declarados y no umbrales óptimos demostrados.

Información mutua detecta dependencia más general. Con X=[-2,-1,1,2] e y=[4,1,1,4], el patrón en U puede tener correlación lineal nula y dependencia clara. La estimación usa tres vecinos y semilla 42; mediana aprendida en el prefijo y máscara de variables binarias. Un puntaje cero no demuestra independencia en muestras pequeñas.

Lasso ajusta una regresión con penalización sobre el valor absoluto de los coeficientes: al aumentar alpha puede llevar algunos exactamente a cero. Se prueban alphas logarítmicos y se conservan coeficientes distintos de cero. Si solo el indicador de ausencia resulta no nulo, se conserva su variable original y se registra esa razón. El objetivo conserva kW. Con predictores muy parecidos, Lasso puede escoger uno u otro: selección no implica causalidad ni unicidad.

Forward agrega una candidata por ronda y mide el error de las propuestas. En esta etapa considera diez posiciones de un ranking Spearman reaprendido en cada entrenamiento interno, y de una a cinco variables directas. Así no existe un prefiltro aprendido con el futuro del pliegue. Los nombres pueden variar con el prefijo: el objeto evaluado es una regla de selección por ranking. Usa Ridge, dos pliegues internos y tres externos, con presupuesto total de 30 minutos. Sus resultados son complementarios y no entran en el ranking principal de métodos. Backward no se ejecutó por costo y alcance; su implementación histórica permanece intacta.

Una interacción A×B representa un efecto conjunto. Si se elige el producto y falta A o B, el cierre de jerarquía incorpora ambos. Por eso k=5 puede producir más de cinco variables reales. La dimensión del estimador puede ser aún mayor si se agregan indicadores de ausencia; ambos conteos se registran.

## C. Preparación, calidad y prevención de fuga

La consigna oficial exige excluir días con menos de 24 lecturas: se aplica en la copia experimental, aun cuando el ADR 0005 admitía una excepción con cierre válido. Los valores imposibles se anulan con reglas del proyecto antes de escalar. Valores extremos legítimos se conservan. Cuartiles, IQR, percentiles y asimetría son diagnósticos por entrenamiento; no se recorta automáticamente toda observación extrema.

La mediana resiste extremos. Cada variable con faltantes en el entrenamiento agrega un indicador de ausencia; por ejemplo, [2,NaN,6] se convierte numéricamente en [2,4,6] junto con [0,1,0]. El 4 no se presenta como consumo observado. Esto evita que una razón indefinida por producción nula sea indistinguible de una razón típica observada. No identifica por sí solo si la ausencia fue parada, falla del sensor o dato no registrado. No se imputan etiquetas.

Se comparan StandardScaler (media y desviación) y RobustScaler (mediana e IQR), sin transformación y con Yeo-Johnson para columnas continuas. Antes de Yeo-Johnson se divide por una escala positiva aprendida para evitar problemas numéricos con productos grandes. Se guardan factor, lambda, medianas, centros, escalas e indicadores en cada resultado. Las transformaciones son univariantes: reutilizarlas entre subconjuntos del mismo pliegue da el mismo ajuste y ahorra trabajo, sin compartir aprendizaje con otros pliegues.

La validación temporal entrena en el pasado y evalúa después. Se usa TimeSeriesSplit con gap=1: la etiqueta del último predictor de entrenamiento pertenece al bloque intermedio anterior al primer predictor evaluado. También se anula la última etiqueta del 70% global y la de cada prefijo entregado a una búsqueda interna. Los rezagos se construyen antes de excluir filas sin etiqueta, para no desplazar la memoria. La evaluación es diaria al cierre y utiliza mediciones observadas de los días anteriores del período evaluado; no es una predicción de todo el período desde un único origen.

Los cuatro métodos principales usan cuatro pliegues externos y tres internos. Los internos eligen configuración; los externos estiman ese procedimiento. Elegir después un ganador entre métodos introduce optimismo de selección: el número no es una estimación final independiente. Validation y test no se usaron para resolver ninguna alternativa. Solo se guardan sus límites y tamaños estructurales.

'''
    contenido+=tabla('División temporal por bloques y etiquetas originales',pd.DataFrame(r['datos']['divisiones']))
    perfil=r['perfil']
    contenido+=tabla('Diagnóstico de entrenamiento: variables con mayor ausencia',perfil.sort_values('faltantes_pct',ascending=False).head(15))
    sensibilidad=perfil.assign(cambio_pearson=(perfil.pearson-perfil.pearson_sin_extremos_1_99).abs())
    contenido+=tabla('Sensibilidad descriptiva de Pearson a extremos legítimos',sensibilidad.sort_values('cambio_pearson',ascending=False)[['variable','pearson','pearson_sin_extremos_1_99','spearman','cambio_pearson']].head(15))
    contenido+='''\n## D. Configuraciones exploradas y resultados desfavorables

La cuadrícula de cantidades no impone un límite final: incluye el total disponible de cada entrenamiento y se refina alrededor del mejor resultado. Los filtros calculan puntajes sobre todas las candidatas permitidas por limpieza; no se parte de una lista elegida globalmente. Las interacciones son las propuestas por el ADR 0014, no todos los productos posibles. El espacio de alphas comienza entre 0.1 y 10000 y se refina logarítmicamente. La búsqueda es amplia pero no exhaustiva sobre todos los subconjuntos posibles.

Cada experimento tiene ID, contexto temporal, parámetros, fechas, tiempos, estado y errores. Los JSON guardan rankings, cobertura, selección directa, padres agregados, parámetros aprendidos, índices, predicciones y MAE de cada pliegue. Los archivos CSV relacionan esos registros por ID. El listado completo, incluidas configuraciones peores, está en el anexo generado y en experimentos.csv. Las advertencias están dentro de los resultados de cada configuración; un aviso de convergencia debe considerarse una limitación de ese ajuste, no evidencia de óptimo exacto.

'''
    contenido+=tabla('Ejecuciones por método y estado',ex.groupby(['metodo','estado']).size().rename('configuraciones').reset_index())
    ok=ex[ex.estado=='completo']
    contenido+=tabla('Diez configuraciones internas con mayor MAE',ok[~ok.contexto.str.contains('evaluacion_externa')].nlargest(10,'mae')[['id','contexto','metodo','mae','std','cantidad','configuracion']])
    contenido+='\n## E. Resultados e interpretación\n\nMAE es el promedio del valor absoluto del error. Si los errores de tres predicciones son −100, 200 y −300 kW, el MAE es 200 kW. Menor es mejor. La desviación entre pliegues informa variación temporal, no un intervalo de confianza. Jaccard mide la proporción compartida entre dos conjuntos: {A,B} y {A,C} dan 1/3. Los tiempos incluyen cómputo y registro local, y no deben compararse como benchmark de hardware.\n\n'
    contenido+=tabla('Métodos principales, protocolo común 4×3',principales)
    contenido+=tabla('Forward complementario, protocolo 3×2',resumen[resumen.metodo=='forward'])
    externos=pd.DataFrame([dict(metodo=m,pliegue=k+1,mae=f['mae'],variables=f['cantidad'],columnas_modelo=f['cantidad_modelo'],fin_train=f['fin_entrenamiento'],inicio_eval=f['inicio_evaluacion']) for m,fs in r['externos'].items() for k,f in enumerate(fs)])
    contenido+=tabla('Resultados externos por pliegue',externos)
    contenido+='\n## F. Variables seleccionadas, coincidencias e interpretación industrial\n\nEl frío actual resume carga reciente, los rezagos persistencia, y el calendario estacionalidad bajo fechas inciertas. Mediciones de compresores y energía pueden reflejar operación del mismo sistema; producción, agua y gas se relacionan con actividad industrial. Estas son interpretaciones plausibles y no afirmaciones causales. No se elimina una medición de hoy por parecerse al frío de hoy: usar hoy para mañana es lícito. Se evita toda medición de mañana como predictor.\n\n'
    for m,v in r['selecciones'].items():
        jer=set(v['seleccion']['por_jerarquia'])
        contenido+=tabla(f'Lista final de {m}',pd.DataFrame([dict(variable=c,incorporada_por_jerarquia=c in jer) for c in v['seleccionadas']]))
    contenido+=tabla('Coincidencias y exclusividades por método',coincidencias(r['selecciones']))
    corr=pd.read_csv(r['carpeta']/'correlaciones_finales.csv',index_col=0)
    pares=pd.DataFrame([dict(variable_a=a,variable_b=b,spearman=corr.loc[a,b]) for i,a in enumerate(corr) for b in corr.columns[i+1:] if abs(corr.loc[a,b])>=.9])
    contenido+=tabla('Pares finales con |Spearman| ≥ 0.9, diagnóstico sin descarte posterior',pares)
    contenido+='\nNo se vuelve a seleccionar con estas correlaciones descriptivas. Ridge estabiliza coeficientes ante colinealidad, pero no convierte variables correlacionadas en evidencia causal. Las listas finales se ajustan sobre todo entrenamiento, por lo que pueden diferir de las listas de cada pliegue externo. El MAE externo pertenece al procedimiento, no a esa lista final aislada.\n'
    contenido+=f'''\n## G. Elección definitiva

El mínimo entre métodos principales es {minimo:.6f} kW. El límite práctico del 1% es {minimo*1.01:.6f} kW. Entre métodos dentro de ese límite se prefiere menor cantidad final, luego mayor estabilidad de conjuntos y menor desvío. El elegido es {ganador['metodo']}. Forward queda fuera de esta decisión por su protocolo distinto. No se afirma que la diferencia sea estadísticamente significativa.

'''
    contenido+=tabla('Métodos dentro de la equivalencia práctica',equiv)
    contenido+=f'''\nLa configuración final es `{json.dumps(contrato['configuracion'],ensure_ascii=False)}`. `variables_seleccionadas.json` contiene nombres y reglas de limpieza/ingeniería. Para aplicar la lista sin reaprender, usar `aplicar_seleccion(X, contrato)` del módulo existente. No pasar automáticamente la configuración experimental ampliada al selector histórico: su preparación es distinta. Para recalcular la selección se ejecuta el motor de experimentos.

## H. Reproducibilidad, versionado y contrato de integración

Desde una instalación limpia, seguir README: clonar, crear cervecera_env con Python 3.12, instalar uv y requirements.txt, obtener los tres originales del aula virtual y ejecutar `python src/experimentos_seleccion.py --sin-cache`. Cada ejecución crea un directorio nuevo. Para reanudar se utiliza `--reanudar results/seleccion/<id>` con las mismas fuentes, configuración y código. No se borra ningún resultado fallido. `results/seleccion/progreso.json` es el estado vivo; eventos.jsonl conserva su historia.

SHA-256 detecta cambios de contenido y evita las debilidades de colisión conocidas de MD5. Los originales no se incluyen en Git. Se guardan hashes de fuentes, código y artefactos, versiones, semilla y HEAD; además una copia exacta del código ejecutado para identificar cambios aún sin commit. El primer error de checksum fue exclusivamente conversión de saltos LF a CRLF en el CSV inicial: los bytes con LF coinciden exactamente con la huella existente. `.gitattributes` fija LF para los CSV procesados.

Los datos finales deben quedar depurados y codificados, sin escalado ni transformación aprendida. Esta etapa entrega la lista y las reglas al módulo 2.4. `dataset_final.csv`, su checksum y `data_lineage.json` siguen pendientes de integración; no se reemplaza el punto de entrada ajeno. El linaje final debe integrar el contrato, la referencia a `{base}`, las reglas, las dimensiones después del descarte, la huella del dataset final y las fechas. No se crea un segundo esquema de linaje incompatible.

'''
    contenido+=tabla('Dos ajustes consecutivos por método',r['determinismo'])
    contenido+=tabla('Checklist contra la consigna oficial',checklist(r))
    contenido+='''\n## I. Archivos y explicación del código

Los archivos creados o modificados por esta etapa figuran en `results/seleccion/auditoria/cambios_etapa.json`, calculados contra el manifiesto del respaldo. Ese registro distingue los cambios previos del equipo de los de esta intervención. Los principales son el motor experimental, su lector/informe, sus pruebas, notebook, ADR 0015, guía, README, .gitattributes, normalización de saltos del CSV y registros de resultados. No se modifican el pipeline de otra integrante ni el notebook preprocesamiento durante esta etapa.

1. Objetivo del código: separar aprendizaje y aplicación, preservar causalidad y registrar cada decisión reproducible.
2. Lectura por funciones: cargar_entrenamiento verifica fuentes y corta; preparar_pliegue aprende limpieza e ingeniería; aprender_preparacion devuelve reglas JSON; aplicar_preparacion no aprende; seleccionar produce nombres; medir ajusta Ridge; buscar explora; ejecutar coordina; exportar relaciona registros.
3. Funcionamiento: los pliegues externos contienen una búsqueda interna completa, con transformaciones ajustadas en cada prefijo, y una evaluación posterior.
4. Ejemplo de tres filas: [2,NaN,6] aprende mediana 4 e indicador [0,1,0]; nuevos datos se rellenan con ese mismo 4, no con una mediana nueva.
5. Alternativa descartada: preparar toda la tabla antes de validar permitiría al futuro influir en límites, bases, medianas y escalas.
6. Relación con el proyecto: se reutilizan las reglas industriales del cierre, limpieza e ingeniería; el comparador no sustituye la Fase 3.
7. Interpretación: tablas externas comparan procedimientos; resultados internos eligen configuraciones; lista final prepara integración.
8. Limitaciones: fechas inciertas, muestra temporal corta, selección entre métodos, umbrales heredados, búsqueda no exhaustiva y diferencias posibles entre hardware.

## J. Estado final, pendientes y restauración

La evidencia numérica de esta ejecución está vinculada a fuentes y código. El estado del notebook se verifica por su registro específico; no debe confundirse la existencia del archivo con su ejecución. La instalación y ejecución en otra máquina no queda certificada por pruebas locales. La revisión humana, resolución del merge previo, commits, push y Pull Request permanecen pendientes de autorización. No se entrenaron los modelos finales ni se consultó test para seleccionar.

Punto de restauración: `fase23-20261113-152329-a7172f93`, en la carpeta hermana `restauracion-fase23-20261113-152329-a7172f93`. Incluye `repositorio/` con .git, índice, MERGE_*, todos los archivos originales, ignorados y nuevos; `manifest.json` con SHA-256; `staged.patch`, `unstaged.patch` y `RESTAURAR.txt`. Se verificó la copia archivo por archivo antes de modificar el repositorio.

Para recuperar exclusivamente esta etapa: cerrar procesos que escriban; guardar primero el estado posterior; consultar cambios_etapa.json y comparar hashes finales con el estado actual. Si coinciden, restaurar desde el respaldo solo los archivos marcados modificados y retirar únicamente los creados por esta etapa. Si difieren por trabajo posterior, fusionar tres versiones (respaldo inicial, versión final de etapa y actual) y conservar los cambios posteriores. No aplicar reset ni clean. El índice y el merge no se cambiaron y no deben reemplazarse si hubo operaciones posteriores ajenas. Para restauración total verificable, copiar repositorio/ a una carpeta nueva y verificar manifest.json; nunca sobrescribir trabajo actual sin preservarlo.

'''
    (out/'seleccion_variables.md').write_text(contenido,encoding='utf-8',newline='\n')
    anexo='# Anexo: todas las configuraciones ejecutadas\n\nLos contextos externos no se usan para ajustar parámetros. Los internos comparan configuraciones. Los errores completos y rankings están en los JSON por ID.\n\n'+markdown(ex)
    (out/'seleccion_configuraciones.md').write_text(anexo,encoding='utf-8',newline='\n')
    adr=f'''# ADR 0015: selección temporal reproducible de variables

- Fecha: 13/11/2026
- Estado: aceptada para selección experimental; integración 2.4 pendiente

## Contexto

Se necesita una lista interpretable para predecir el frío del siguiente bloque, evitando elegir cantidades arbitrarias y fuga de datos. Los resultados pertenecen a `{r['carpeta'].name}`; código, fuentes y configuraciones archivados con SHA-256.

## Decisión

Se recomienda {ganador['metodo']}, con {ganador['cantidad']} variables después de cerrar jerarquía. Configuración: `{json.dumps(contrato['configuracion'],ensure_ascii=False)}`. Se conserva y sin transformar ni escalar. La aplicación usa `aplicar_seleccion(X, contrato)` con variables_seleccionadas.json. Los parámetros experimentales no se pasan al selector provisional histórico.

## Justificación

MAE externo medio {ganador['mae']:.6f} kW; desviación {ganador['std']:.6f} kW; Jaccard medio {ganador['jaccard']:.6f}. Los cuatro métodos principales se evalúan con cuatro pliegues externos y tres internos, gap=1 y Ridge alpha=100. Dentro del 1% del mínimo ({minimo*1.01:.6f} kW) se prefiere menor conjunto. Los tamaños y alphas se eligen en búsquedas internas. Las cifras se calculan automáticamente desde registros y se presentan también en las tablas 6 y 8 del notebook.

{markdown(principales)}

Lista definitiva:

{markdown(pd.DataFrame({'variable':contrato['seleccionadas']}))}

## Alternativas descartadas

Los resultados completos de Spearman, Pearson, información mutua y Lasso, incluso peores y fallidos, están en experimentos.csv y el anexo del informe. Se comparan StandardScaler/RobustScaler y con/sin Yeo-Johnson. Forward se ejecuta como complemento con diez candidatas por pliegue, una a cinco directas, dos pliegues internos, tres externos y 30 minutos máximos; su MAE no participa del ranking principal. Backward no se ejecutó por costo y alcance; se conserva su código existente.

## Limitaciones

El MAE evalúa el procedimiento y no equivale a rendimiento final en test. Elegir método sobre resultados externos produce optimismo de selección. Fechas rotuladas inciertas, umbrales de calidad declarados y memoria por bloque. Indicadores distinguen ausencia de observación sin identificar siempre su causa. La consigna obliga a invalidar menos de 24 lecturas, prevaleciendo sobre excepción histórica; debe integrarse en 2.4. Se anula última etiqueta del entrenamiento autorizado y de cada prefijo de búsqueda. El pipeline, dataset_final.csv sin escalar, su checksum y data_lineage.json quedan para integración, junto con revisión humana y operaciones Git autorizadas.

Informe completo: [seleccion_variables.md](../informes/seleccion_variables.md). Registros: `{base}`. Esta decisión sustituye la propuesta anterior; el respaldo conserva íntegra su versión histórica.
'''
    (RAIZ/'docs/decisions/0015-seleccion-de-variables.md').write_text(adr,encoding='utf-8',newline='\n')
    return out/'seleccion_variables.md'


if __name__=='__main__':
    print(generar_informe())
